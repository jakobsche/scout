# Scout

Scout wird ein Dateimanager, der Funktionen auf dem Mac zur Verfügung stellen soll, die dort im Finder fehlen oder aus der Sicht von Benutzern anderer Systeme schwer zu finden sind.

Der aktuelle Quelltext ist ein Prototyp, der lokale Dateisysteme mit LCL-Komponenten übersichtlich anzeigen soll. Vorschläge zu Funktionen und Mitarbeit an Details sind willkommen.

Im Verzeichnis deploy befinden sich ein compilierbarer Quellcode und compilierte ausführbare Versionen davon. Der aktuelle Entwicklungsstand befindet sich im Hauptverzeichnis.
